package com.hcl.resttemplate.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {
	
	

}
