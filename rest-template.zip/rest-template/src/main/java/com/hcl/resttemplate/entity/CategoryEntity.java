package com.hcl.resttemplate.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="CATEGORY" , uniqueConstraints = {@UniqueConstraint(columnNames="CATEGORY_ID")})
public class CategoryEntity implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CATEGORY_ID")
	private long categoryID;
	
	@Column(name = "CATEGORY_NAME" , unique=false , nullable=false , length=100)
	private String categoryName;
	
	
	
	
	
	
	

}
